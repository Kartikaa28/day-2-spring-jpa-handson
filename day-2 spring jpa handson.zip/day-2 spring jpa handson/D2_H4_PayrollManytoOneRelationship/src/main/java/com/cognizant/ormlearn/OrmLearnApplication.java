package com.cognizant.ormlearn;

import java.sql.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.cognizant.ormlearn.model.Department;
import com.cognizant.ormlearn.model.Employee;
import com.cognizant.ormlearn.service.DepartmentService;
import com.cognizant.ormlearn.service.EmployeeService;
import com.cognizant.ormlearn.service.SkillService;

@SpringBootApplication
public class OrmLearnApplication {

	private static final Logger LOGGER = LoggerFactory.getLogger(OrmLearnApplication.class);

	// static references
	private static EmployeeService employeeService;
	private static DepartmentService departmentService;
	private static SkillService skillService;

	public static void main(String[] args) {
		ApplicationContext context = SpringApplication.run(OrmLearnApplication.class, args);

		// assigning from context
		employeeService = context.getBean(EmployeeService.class);
		departmentService = context.getBean(DepartmentService.class);
		skillService = context.getBean(SkillService.class);

		// testGetEmployee();
		//testAddEmployee();
		testUpdateEmployee();
		LOGGER.info("Start");
	}

	private static void testGetEmployee() {
		LOGGER.info("Start");
		Employee employee = employeeService.get(1);

		LOGGER.debug("Employee:{}", employee);
		LOGGER.debug("Department:{}", employee.getDepartment());
		LOGGER.info("End");

	}

	public static void testAddEmployee() {
		LOGGER.info("Start");

		Employee employee = new Employee();
		employee.setId(101);
		employee.setName("Pavi");
		employee.setDateOfBirth(Date.valueOf("1999-09-03"));
		employee.setSalary(100.01);
		employee.setPermanent(true);

		Department department = departmentService.get(1);
		employee.setDepartment(department);

		employeeService.save(employee);
		LOGGER.debug("Employee:{}", employee);
		LOGGER.info("End");
	}

	public static void testUpdateEmployee() {
		Employee employee = employeeService.get(6);

		Department department = departmentService.get(2);
		employee.setDepartment(department);

		employeeService.save(employee);
		LOGGER.debug("Employee:{}", employee);
		LOGGER.info("End");
	}

}

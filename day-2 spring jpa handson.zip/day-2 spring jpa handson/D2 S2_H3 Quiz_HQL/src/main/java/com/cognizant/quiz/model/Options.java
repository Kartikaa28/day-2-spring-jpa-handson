package com.cognizant.quiz.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "options")
public class Options {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "op_id")
	private int optionId;

	@Column(name = "op_qt_id")
	private int questionId;

	@Column(name = "op_score")
	private double optionScore;

	@Column(name = "op_text")
	private String optionText;

	public int getOptionId() {
		return optionId;
	}

	public void setOptionId(int optionId) {
		this.optionId = optionId;
	}

	public int getQuestionId() {
		return questionId;
	}

	public void setQuestionId(int questionId) {
		this.questionId = questionId;
	}

	public double getOptionScore() {
		return optionScore;
	}

	public void setOptionScore(double optionScore) {
		this.optionScore = optionScore;
	}

	public String getOptionText() {
		return optionText;
	}

	public void setOptionText(String optionText) {
		this.optionText = optionText;
	}

	@Override
	public String toString() {
		return "Options [optionId=" + optionId + ", questionId=" + questionId + ", optionScore=" + optionScore
				+ ", optionText=" + optionText + "]";
	}

}

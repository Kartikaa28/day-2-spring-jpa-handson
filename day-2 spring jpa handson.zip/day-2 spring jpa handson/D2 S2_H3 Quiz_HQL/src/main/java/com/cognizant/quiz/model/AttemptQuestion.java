package com.cognizant.quiz.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "attempt_question")
public class AttemptQuestion {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "aq_id")
	private int attemptQuestionId;
	
	@Column(name = "aq_at_id")
	private int attemptId;
	
	@Column(name = "aq_qt_id")
	private int questionId;

	public int getAttemptQuestionId() {
		return attemptQuestionId;
	}

	public void setAttemptQuestionId(int attemptQuestionId) {
		this.attemptQuestionId = attemptQuestionId;
	}

	public int getAttemptId() {
		return attemptId;
	}

	public void setAttemptId(int attemptId) {
		this.attemptId = attemptId;
	}

	public int getQuestionId() {
		return questionId;
	}

	public void setQuestionId(int questionId) {
		this.questionId = questionId;
	}

	@Override
	public String toString() {
		return "AttemptQuestion [attemptQuestionId=" + attemptQuestionId + ", attemptId=" + attemptId + ", questionId="
				+ questionId + "]";
	}

}

package com.cognizant.quiz.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cognizant.quiz.model.Attempt;

@Repository
public interface AttemptRepository extends JpaRepository<Attempt, Integer>{
	
	@Query(value = "SELECT a FROM Attempt a left join fetch a.userId")
	public Attempt getAttempt(int userId, int attemptId);

}

package com.cognizant.quiz.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "attempt")
public class Attempt {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "at_id")
	private int attemptId;

	@Column(name = "at_date")
	private Date attemptDate;

	@Column(name = "at_us_id")
	private int userId;

	@Column(name = "at_score")
	private double attemptScore;

	public int getAttemptId() {
		return attemptId;
	}

	public void setAttemptId(int attemptId) {
		this.attemptId = attemptId;
	}

	public Date getAttempteddate() {
		return attemptDate;
	}

	public void setAttempteddate(Date attemptDate) {
		this.attemptDate = attemptDate;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public double getAttemptScore() {
		return attemptScore;
	}

	public void setAttemptScore(double attemptScore) {
		this.attemptScore = attemptScore;
	}

	@Override
	public String toString() {
		return "Attempt [attemptId=" + attemptId + ", attemptDate=" + attemptDate + ", userId=" + userId
				+ ", attemptScore=" + attemptScore + "]";
	}

}

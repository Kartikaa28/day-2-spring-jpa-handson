package com.cognizant.quiz.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "attempt_option")
public class AttemptOption {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ao_id")
	private int attemptOptionId;

	@Column(name = "ao_op_id")
	private int optionId;

	@Column(name = "ao_aq_id")
	private int attemptQuestionId;

	@Column(columnDefinition = "bit", name = "ao_selected")
	private int selected;

	public int getAttemptOptionId() {
		return attemptOptionId;
	}

	public void setAttemptOptionId(int attemptOptionId) {
		this.attemptOptionId = attemptOptionId;
	}

	public int getOptionId() {
		return optionId;
	}

	public void setOptionId(int optionId) {
		this.optionId = optionId;
	}

	public int getAttemptQuestionId() {
		return attemptQuestionId;
	}

	public void setAttemptQuestionId(int attemptQuestionId) {
		this.attemptQuestionId = attemptQuestionId;
	}

	public int getSelected() {
		return selected;
	}

	public void setSelected(int selected) {
		this.selected = selected;
	}

	@Override
	public String toString() {
		return "AttemptOption [attemptOptionId=" + attemptOptionId + ", optionId=" + optionId + ", attemptQuestionId="
				+ attemptQuestionId + ", selected=" + selected + "]";
	}

}

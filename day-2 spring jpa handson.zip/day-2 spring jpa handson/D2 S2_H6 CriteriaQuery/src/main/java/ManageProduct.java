import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;

public class ManageProduct {
	@Autowired
	Product product;
	private static SessionFactory factory;

	public static void main(String[] args) {

		try {
			factory = new Configuration().configure().buildSessionFactory();
		} catch (Throwable ex) {
			System.err.println("Failed to create sessionFactory object." + ex);
			throw new ExceptionInInitializerError(ex);
		}

		ManageProduct mp = new ManageProduct();
		mp.searchProduct();

	}

	public void searchProduct() {
		Session session = factory.openSession();
		Transaction tx = null;

		try {

			tx = session.beginTransaction();

			Criteria crit = session.createCriteria(Product.class);
			crit.add(Restrictions.like(product.getProductName(), "lap%", MatchMode.ANYWHERE));
			List<Product> results = crit.list();

			for (Product p : results)
				System.out.println(p);

			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}
	}
}
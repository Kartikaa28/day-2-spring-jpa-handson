public class Product {

	private int id;
	private String productName;
	private String ProductFeatures;

	public Product(int id, String productName, String productFeatures) {
		super();
		this.id = id;
		this.productName = productName;
		ProductFeatures = productFeatures;
	}
	
	public Product() {
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getProductFeatures() {
		return ProductFeatures;
	}

	public void setProductFeatures(String productFeatures) {
		ProductFeatures = productFeatures;
	}

	@Override
	public String toString() {
		return "Product [id=" + id + ", productName=" + productName + ", ProductFeatures=" + ProductFeatures + "]";
	}

}